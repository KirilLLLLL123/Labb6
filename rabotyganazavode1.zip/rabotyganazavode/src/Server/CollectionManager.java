package Server;
/** внутренняя логика Stream-API */
public class CollectionManager {
}

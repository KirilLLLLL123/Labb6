package Command.modelall;

public enum CommandName {
    ADD,
    SHOW,
    INFO,
    REMOVE_BY_ID,
    CLEAR,
    EXIT
}

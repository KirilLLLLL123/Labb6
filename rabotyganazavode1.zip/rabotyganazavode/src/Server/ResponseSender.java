package Server;
/** шлёт Response */
public class ResponseSender {
}

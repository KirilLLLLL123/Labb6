package Client;

public class Connection {
}

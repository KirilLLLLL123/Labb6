package Client;

public class ConsoleReader {
}

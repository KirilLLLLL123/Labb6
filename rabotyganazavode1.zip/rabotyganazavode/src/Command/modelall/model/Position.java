package Command.modelall.model;

public enum Position {
    LABORER,
    HEAD_OF_DIVISION,
    CLEANER;
}
